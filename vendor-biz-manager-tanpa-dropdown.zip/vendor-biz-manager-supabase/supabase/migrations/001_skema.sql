-- Vendor Biz Manager: skema, kekangan, indeks, RLS dan fungsi save_event
create extension if not exists pgcrypto;

create table public.profiles(
  id uuid primary key references auth.users(id) on delete cascade, -- id = owner_id untuk profil
  full_name text, created_at timestamptz not null default now());

create table public.menus(
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null check(length(trim(name))>0), category text,
  price numeric(12,2) not null check(price>=0), est_cost numeric(12,2) check(est_cost>=0),
  description text, active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(id,owner_id));
create unique index menus_nama_uq on public.menus(owner_id,lower(name));

create table public.events(
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null check(length(trim(name))>0), organizer text, venue text,
  start_date date not null, end_date date not null, check(end_date>=start_date),
  status text not null check(status in('upcoming','ongoing','completed','cancelled')),
  notes text, sales_mode text not null default 'total' check(sales_mode in('total','daily')),
  cost_mode text check(cost_mode in('A','B')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(id,owner_id));
create unique index events_dup_uq on public.events(owner_id,lower(name),start_date);
create index events_owner_tarikh on public.events(owner_id,start_date desc);

-- Semua jadual anak mengikat (event_id, owner_id): rekod anak tidak boleh milik pemilik lain.
create table public.event_menus(
  event_id uuid not null, menu_id uuid not null,
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  price numeric(12,2) not null check(price>=0), note text,
  primary key(event_id,menu_id),
  foreign key(event_id,owner_id) references public.events(id,owner_id) on delete cascade,
  foreign key(menu_id,owner_id) references public.menus(id,owner_id) on delete restrict);
create index event_menus_menu on public.event_menus(menu_id);

create table public.sales(
  event_id uuid primary key, owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  total numeric(12,2) not null check(total>=0), recorded_on date, notes text,
  foreign key(event_id,owner_id) references public.events(id,owner_id) on delete cascade);

create table public.daily_records(
  event_id uuid not null, day date not null,
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  sales numeric(12,2) not null check(sales>=0), primary key(event_id,day),
  foreign key(event_id,owner_id) references public.events(id,owner_id) on delete cascade);

create table public.expenses(
  id uuid primary key default gen_random_uuid(), event_id uuid not null,
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  category text not null check(category in('Bahan mentah','Sewa petak','Gaji pekerja','Pengangkutan','Minyak & tol','Gas & utiliti','Pembungkusan','Lain-lain')),
  description text, spent_on date not null, amount numeric(12,2) not null check(amount>=0),
  foreign key(event_id,owner_id) references public.events(id,owner_id) on delete cascade);
create index expenses_event on public.expenses(event_id);

create table public.capital(
  event_id uuid primary key, owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  amount numeric(12,2) not null check(amount>=0),
  foreign key(event_id,owner_id) references public.events(id,owner_id) on delete cascade);

create table public.archived_events(
  event_id uuid primary key, owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  archived_at timestamptz not null default now(),
  foreign key(event_id,owner_id) references public.events(id,owner_id) on delete cascade);

-- updated_at (untuk pengesanan konflik). Perubahan anak turut mengemas kini acara induk.
create function public.touch() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;
create trigger t_menus before update on public.menus for each row execute function public.touch();
create trigger t_events before update on public.events for each row execute function public.touch();
create function public.touch_parent() returns trigger language plpgsql as $$
begin update public.events set updated_at=now() where id=coalesce(new.event_id,old.event_id); return null; end $$;
create trigger t_em after insert or update or delete on public.event_menus for each row execute function public.touch_parent();
create trigger t_s after insert or update or delete on public.sales for each row execute function public.touch_parent();
create trigger t_d after insert or update or delete on public.daily_records for each row execute function public.touch_parent();
create trigger t_x after insert or update or delete on public.expenses for each row execute function public.touch_parent();
create trigger t_c after insert or update or delete on public.capital for each row execute function public.touch_parent();

-- Profil dicipta automatik apabila pengguna dicipta
create function public.baru_pengguna() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id) values(new.id) on conflict do nothing; return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.baru_pengguna();

-- RLS: setiap jadual hanya boleh diakses oleh pemiliknya
do $$ declare t text; begin
 foreach t in array array['menus','events','event_menus','sales','daily_records','expenses','capital','archived_events'] loop
  execute format('alter table public.%I enable row level security',t);
  execute format('create policy "pemilik sahaja" on public.%I for all to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid())',t);
 end loop; end $$;
alter table public.profiles enable row level security;
create policy "profil sendiri" on public.profiles for all to authenticated using(id=auth.uid()) with check(id=auth.uid());
revoke all on all tables in schema public from anon;
grant select,insert,update,delete on all tables in schema public to authenticated;

-- Simpan satu acara beserta semua data anak dalam satu transaksi. Selamat diulang (idempotent).
create function public.save_event(p jsonb, base timestamptz default null) returns timestamptz
language plpgsql security invoker set search_path=public as $$
declare eid uuid:=(p->>'id')::uuid; cur timestamptz; res timestamptz;
begin
 if auth.uid() is null then raise exception 'TIDAK_LOG_MASUK'; end if;
 select updated_at into cur from events where id=eid for update;
 if found and base is not null and cur<>base then raise exception 'KONFLIK'; end if;
 insert into events(id,name,organizer,venue,start_date,end_date,status,notes,sales_mode,cost_mode)
 values(eid,p->>'name',p->>'org',p->>'venue',(p->>'start')::date,(p->>'end')::date,p->>'status',p->>'notes',p->>'salesMode',p->>'costMode')
 on conflict(id) do update set name=excluded.name,organizer=excluded.organizer,venue=excluded.venue,start_date=excluded.start_date,
  end_date=excluded.end_date,status=excluded.status,notes=excluded.notes,sales_mode=excluded.sales_mode,cost_mode=excluded.cost_mode;
 if p->>'total' is not null then
  insert into sales(event_id,total,recorded_on,notes) values(eid,(p->>'total')::numeric,nullif(p->>'salesDate','')::date,p->>'salesNote')
  on conflict(event_id) do update set total=excluded.total,recorded_on=excluded.recorded_on,notes=excluded.notes;
 else delete from sales where event_id=eid; end if;
 if p->>'capital' is not null then
  insert into capital(event_id,amount) values(eid,(p->>'capital')::numeric) on conflict(event_id) do update set amount=excluded.amount;
 else delete from capital where event_id=eid; end if;
 delete from event_menus where event_id=eid;
 insert into event_menus(event_id,menu_id,price,note) select eid,(x->>'mid')::uuid,(x->>'price')::numeric,x->>'note' from jsonb_array_elements(coalesce(p->'menus','[]')) x;
 delete from daily_records where event_id=eid;
 insert into daily_records(event_id,day,sales) select eid,key::date,value::numeric from jsonb_each_text(coalesce(p->'daily','{}'));
 delete from expenses where event_id=eid and id not in(select (x->>'id')::uuid from jsonb_array_elements(coalesce(p->'exp','[]')) x);
 insert into expenses(id,event_id,category,description,spent_on,amount)
  select (x->>'id')::uuid,eid,x->>'cat',x->>'desc',(x->>'date')::date,(x->>'amt')::numeric from jsonb_array_elements(coalesce(p->'exp','[]')) x
  on conflict(id) do update set category=excluded.category,description=excluded.description,spent_on=excluded.spent_on,amount=excluded.amount;
 select updated_at into res from events where id=eid; return res;
end $$;
revoke execute on function public.save_event(jsonb,timestamptz) from public,anon;
grant execute on function public.save_event(jsonb,timestamptz) to authenticated;
