-- UJIAN RLS. Cipta 2 pengguna ujian (A dan B) di Authentication > Users, salin ID mereka,
-- ganti AAAAAAAA-... dan BBBBBBBB-... di bawah, kemudian jalankan di SQL Editor.
-- Semua perubahan dibatalkan (rollback). Cari "LULUS" atau "GAGAL" dalam hasil.
begin;
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"}',true);
insert into menus(name,price) values('ujian milik A',1);
select set_config('request.jwt.claims','{"sub":"BBBBBBBB-BBBB-BBBB-BBBB-BBBBBBBBBBBB"}',true);
select case when count(*)=0 then 'LULUS: B tidak nampak data A' else 'GAGAL: B nampak data A' end as keputusan from menus;
update menus set name='diubah B';  -- 0 baris dikemas kini kerana RLS
select case when count(*)=0 then 'LULUS: B tidak boleh ubah data A' else 'GAGAL' end from menus where name='diubah B';
do $$ begin
 begin insert into menus(owner_id,name,price) values('AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA','palsu',1);
  raise exception 'GAGAL: B menulis sebagai A';
 exception when insufficient_privilege then raise notice 'LULUS: B tidak boleh menulis sebagai A'; end;
end $$;
reset role; set local role anon;
do $$ begin begin perform count(*) from public.menus; raise exception 'GAGAL: anon boleh baca';
 exception when insufficient_privilege then raise notice 'LULUS: anon ditolak'; end; end $$;
rollback;
-- Ulang ujian serupa untuk: events, event_menus, sales, daily_records, expenses, capital, archived_events, profiles.
